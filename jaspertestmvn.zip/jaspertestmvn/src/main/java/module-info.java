module es.cifpcarlosiii.jaspertestmvn {
    requires javafx.controls;
    requires javafx.web;
    requires java.sql;
    requires java.desktop;
    requires java.logging;
    requires jasperreports;
    
    exports es.cifpcarlosiii.jaspertestmvn;
}
